// app/javascripts/apiConfig.js
const API_DOMAIN = 'http://localhost:3000';

const apiConfig = {
  apiUrl: `${API_DOMAIN}/api/v1`
};

export default apiConfig;
