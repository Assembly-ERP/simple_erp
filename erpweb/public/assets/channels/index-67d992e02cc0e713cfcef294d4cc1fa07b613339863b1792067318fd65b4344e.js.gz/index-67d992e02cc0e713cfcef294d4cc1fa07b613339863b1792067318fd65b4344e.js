// app/javascript/channels/index.js
//import "../channels/consumer";
//import "../channels/customer_channel";

console.log("Channels initialized");
